﻿def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "{\"message\": \"Lambda placeholder - deploy real code after terraform apply\"}"
    }
